import 'package:desafio_ventilador/desafio_ventilador.dart';
import 'package:test/test.dart';

void main() {
  test('calculate', () {
    expect(calculate(), 42);
  });
}
